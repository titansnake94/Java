package task2;
import javax.swing.JOptionPane;

public class BankAccount {
	String name;
	float balance;
	
	BankAccount(String name, float d){
		if(d<0) {
			//error for (a) question
			System.out.println("Invalid balance");
			//error for (b) question with gui
			JOptionPane.showMessageDialog(null, "Invalid Balance", "Error", JOptionPane.ERROR_MESSAGE);
		}else {
			this.name = name;
			this.balance = d;
		}
	}
	
	
	public void payIn (float amount) {
		this.balance += amount;
	}
	
	public float getBalance () {
		return this.balance;
	}
	
	public void setName (String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	
}
