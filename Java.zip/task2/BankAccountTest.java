package task2; 
import javax.swing.JOptionPane;
public class BankAccountTest {

	public static void main(String[] args) {
		
		//code for the (a) question which uses the console without the use of Swing 
		
		BankAccount b1 = new BankAccount("B1",2700.00f);
		BankAccount b2 = new BankAccount("b2",-120.00f);
		System.out.println(b1.getName());
		System.out.println(b1.getBalance());
		
		
		//end of (a) code
		
		//Code for the (b) question that needs gui
		/*
		String name1 = JOptionPane.showInputDialog("Enter Bank1 Name"); //Simple input dialog with the text "enter bank1 name" , it returns a string
		String balance1 = JOptionPane.showInputDialog("Enter Bank1 Balance");// same for the balance
		BankAccount b1 = new BankAccount(name1,Float.valueOf(balance1));//Create a new BankAccount instance with the retrieved values and using Float.valueOf() to convert string to float
		String name2 = JOptionPane.showInputDialog("Enter Bank2 Name");//Same for bank2
		String balance2 = JOptionPane.showInputDialog("Enter Bank2 Balance");
		BankAccount b2 = new BankAccount(name2,Float.valueOf(balance2));
		//then we simply output a MessageDialog with the title (b1.getName+" Balance") and content of (b1.getBalance())
		JOptionPane.showMessageDialog(null,b1.getBalance(),b1.getName()+" Balance",JOptionPane.PLAIN_MESSAGE);
		//end of (b) code
*/
	}

}
