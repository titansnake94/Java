package task3;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class CourseStats {

	public static void main(String[] args) {
		//code for (a) without gui
		//first we set the passes and failures to 0 and students to 1, then using while loop we go through all 20 students
		int passes=0;
		int failures=0;
		int student_count=1;
		Scanner scan = new Scanner(System.in);
		while (student_count<=20) {
			System.out.println("Enter the result:  ");
			int x = scan.nextInt();
			if(x==1) {
				passes++;
			}
			if(x==2) {
				failures++;
			}
			student_count++;
		}
		
		System.out.println("Number of passes : "+passes);
		System.out.println("Number of failures : "+failures);
		if(passes>16) {
			System.out.println("Congratulations to the Tutors!");    
		}
		//end of code for (a) without interface (gui)
		
		//Each time we find a value = 1 we increment the number of passes
		//Each time we find a value = 2 we increment the number of failures
		
		
		//code for the (b) part that uses interface
		/*
		int passes=0;
		int failures=0;
		int student_count=1;
		while (student_count<=20) {
			String res = JOptionPane.showInputDialog("Enter the result:  ");
			
		
			if(res.equals("1")) {
				passes++;
			}
			if(res.equals("2")) {
				failures++;
			}
			student_count++;
		}
		
		String res="Passes : "+String.valueOf(passes)+" \nFailures : "+String.valueOf(failures);
		if(passes>16) {
			
			  res+="\nCongratulations to the Tutors!";
		}
	
		
		JOptionPane.showMessageDialog(null,res,"Result",JOptionPane.PLAIN_MESSAGE);	
		
		
		*/

		//end ofcode for the (b) part that uses interface
		
		
	}

}
