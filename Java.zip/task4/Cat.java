package task4;

public class Cat extends Animal {

	
    public void meow()
    {
         System.out.println("meooww!");
    }

    public void move()
   {
        System.out.println("Jumping");
    }

	
}
