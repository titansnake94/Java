package task4;

public class Lion extends Animal{

	
	public void roar()
    {
         System.out.println("Roooaar!");
    }
	
	 public void move()
	    {
	         System.out.println("Sitting");
	     }

	
}
