package task4;

public class AnimalTest {

	public static void main(String[] args) {

			
		Dog dog = new Dog();
		Cat cat = new Cat();
		Lion lion = new Lion();
		dog.bark();
		dog.sleep();
		lion.eat();
		cat.sleep();
		
		dog.move();
		lion.move();
		cat.move();
		

	}

}
