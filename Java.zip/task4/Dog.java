package task4;

public class Dog extends Animal {

	
	
	public void bark()
    {
         System.out.println("Woof!");
    }

	public void move() {
		System.out.println("Running");
		
	}

	
	
}
