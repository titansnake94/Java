package task4;

public abstract class Animal {
	public boolean isAPet = true;
	public String owner = "John";
	
	
	public abstract void move();
	
	public void sleep()
	{
	     System.out.println("Sleeping");
	}
	
	
	public void eat()
	{
	     System.out.println("Eating");
	}





}
