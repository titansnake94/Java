package task1;

import java.util.Scanner;

public class Task1 {

	
	//Scanner is used to get input from the console , we need to first create a scanner
	
	public static Scanner scan = new Scanner(System.in);
	
	// I wanted to make it clean and create a function for the first question , i called it program A
	private static void progA() {
		//Scans the first input
		System.out.print("Please enter the first input : ");
		int a = scan.nextInt();
		//Scans the second input
		System.out.print("Please enter the Second input : ");
		int b = scan.nextInt();
		//Calculates the sum and stores it in variable s
		int s = a+b;
		//prints out the result stored in s , I tried to make a clean printing and including the values of a and b
		System.out.println("The sum of "+a+"+"+b+" is "+s);
	}
	
	//this is the function for the second question
	private static void progB() {
		
		//same thing we are just getting the inputs 
		System.out.print("Please enter the first input : ");
		int a = scan.nextInt();
		System.out.print("Please enter the Second input : ");
		int b = scan.nextInt();
		System.out.print("Please enter the Third input : ");
		int c = scan.nextInt();
		
		System.out.println("the numbers in order : ");
		//this is just basic if statements used to compares the 3 inputs
		if(a>b && a>c) {
			System.out.print(a+",");
			if(b>c) {
				System.out.print(b+","+c);
			}else {
				System.out.print(c+","+b);
			}
		}
		
		if(b>a && b>c) {
			System.out.print(b+",");
			if(a>c) {
				System.out.print(a+","+c);
			}else {
				System.out.print(c+","+a);
			}
		}
		
		if(c>a && c>b) {
			System.out.print(c+",");
			if(a>b) {
				System.out.print(a+","+b);
			}else {
				System.out.print(b+","+a);
			}
		}
		//now that we printed the the numbers in order we need the average, that is just the sum/3
		//this is just to return to line without printing anything
		System.out.println();
		//this is to print out the average
		System.out.println("The average is "+(a+b+c)/3f);
		
		
		/* 
		 * Please note that instead of printing out the compared result directly, you can store it in a string
		 * 		String s = "";
				if(a>b && a>c) {
					s+=String.valueOf(a)+","
					if(b>c) {
						s+=String.valueOf(b)+","+String.valueOf(c)
					}else {
						s+=String.valueOf(c)+","+String.valueOf(b)
					}
				}
		 * ... and so on
		 *
		 * this is just in case you wanted to use the string for other problems or want another way to print it 
		 * 
		 * */
		
	}
	
	
	public static void main(String[] args) {
		//Program (a)
		
			//running program (a) for 9 times to get the desired output by the question (summing 1+2, 2+3 ...)
	/*
		progA();
		progA();
		progA();
		progA();
		progA();
		progA();
		progA();
		progA();
		progA();
		*/
		//Program (b) for 10 times to get the desired out put for (1 2 3, 4 5 6, ...)
		
		progB();
		progB();
		progB();
		progB();
		progB();
		progB();
		progB();
		progB();
		progB();
		progB();

	}
	//end of program (b)

}
