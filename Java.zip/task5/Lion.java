package task5;

public class Lion  extends Animal{
	
	
	Lion(){
		super.setOwner("Peter");
	}
	
	public void roar()
    {
         System.out.println("Roooaar!");
    }
	
    public void makeSound()
    {
         System.out.println("The Lion roars!");
    }

	
}
