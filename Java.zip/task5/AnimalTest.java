package task5;

public class AnimalTest {

	
	public static void main(String[] args) {
		
		Dog dog = new Dog();
		Cat cat = new Cat();
		Lion lion = new Lion();
		
		dog.makeSound();
		cat.makeSound();
		lion.makeSound();
		
		dog.sleep();
		lion.eat();
		cat.sleep();
		
		System.out.println("Dog owner : "+dog.getOwner());
		System.out.println("Cat owner : "+cat.getOwner());
		System.out.println("Lion owner : "+lion.getOwner());
		
		
		
	}
	
	
}
