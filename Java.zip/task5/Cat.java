package task5;

public class Cat  extends Animal{

	
	Cat(){
		super.setOwner("Alice");
	}
	
	 public void meow()
	    {
	         System.out.println("meooww!");
	    }
	 
	 
	 public void makeSound()
     {
          System.out.println("The cat does meow!");
     }

	 
}
