package task5;

public class Animal {
	public boolean isAPet = true;
	public String owner = "John";
	
	
	public void sleep()
	{
	     System.out.println("Sleeping");
	}
	 
	public void eat()
	{
	     System.out.println("Eating");
	}
	
	
	 public void makeSound()
	 {
	      System.out.println("the animal makes sounds");
	 }

	 public String getOwner()
	 {
	        return owner;
	 }
	 
	 public void setOwner(String newOwner)
	 {
	       owner = newOwner;
	 }

	
}
