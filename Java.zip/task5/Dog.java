package task5;

public class Dog extends Animal {
	
	Dog(){
		super.setOwner("Mike");
	}
	
	public void bark()
    {
         System.out.println("Woof!");
    }
	
	
	public void makeSound()
    {
         System.out.println("The dog barks!");
    }

	
}
